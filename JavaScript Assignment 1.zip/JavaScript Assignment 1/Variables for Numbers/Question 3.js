// 3. Declare a variable called birthYear & assign to it your
// birth year. Show the following message in your browser:

var birthYear = 2000;

document.write("My Birth Year is: " + birthYear + "<br>");
document.write("Data Type of my declared variable is: " + typeof birthYear);