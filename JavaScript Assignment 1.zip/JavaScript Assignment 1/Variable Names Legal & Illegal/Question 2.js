// 2. Declare 5 legal & 5 illegal variable names.


// Declare legal variables
var firstName, lastName, fatherName, gender, courseName;

// Declare illegal variables
var Firstname, Lastname, Fathername, Gender, Coursename;