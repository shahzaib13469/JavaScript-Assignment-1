// 2. Declare a variable called myName & assign to it a string
// that represents your Full Name.

var myName = "Hafiz Shahzaib Ali";
console.log(myName);