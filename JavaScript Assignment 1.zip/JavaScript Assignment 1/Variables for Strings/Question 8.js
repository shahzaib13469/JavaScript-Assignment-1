// 8. Write a script to display this in browser through JS

var text = "Yah! I can write HTML content through JavaScript";

document.write(text);