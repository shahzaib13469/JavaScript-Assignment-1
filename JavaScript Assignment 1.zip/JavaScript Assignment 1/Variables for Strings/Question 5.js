// 5. Write a script to display the following alert using one JS
// variable:

var abc = " PIZZA \n PIZZ \n PIZ \n PI \n P";
alert(abc);