// 4. Write a script to save student’s bio data in JS variables and
// show the data in alert boxes.

var stdName = "John Doe";
var age = 15;
var course = "Certified Mobile Application Development";

alert(stdName);
alert(age + " years old");
alert(course);