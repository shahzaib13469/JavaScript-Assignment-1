// 6. This if/else statement does not work. Try to fix it:
// var greeting;
// var hour = 13;
// if (hour < 18) {
// greeting = "Good day";
// else
// greeting = "Good evening";
// }

var greeting;
var hour = 13;
if (hour < 18) 
{
    greeting = "Good day";
    console.log(greeting);
}
else
{
    greeting = "Good evening";
    console.log(greeting);
}