// 4. Write a that takes a character (i.e. string of length 1) and returns true if it is a vowel, false otherwise

var char = prompt("Enter Character...");

if(char == "a" || char == "A" || char == "e" || char == "E" || char == "i" || char == "I" || char == "o" || char == "O" || char == "u" || char == "U")
{
    console.log("True");
}
else
{
    console.log("False");
}