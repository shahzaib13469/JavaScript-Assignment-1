// 5. Generate the following message through browser’s
// developer console:

var msg = "Hello... I can run JS through my web browser's console ";
alert(msg);