// 1. Write a script to greet your website visitor using JS alert
// box.

var msg = "Hello this is my First JavaScript Program";
alert(msg);