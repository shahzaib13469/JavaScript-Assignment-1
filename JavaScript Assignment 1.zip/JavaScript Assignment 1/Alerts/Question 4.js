// 4. Write a script to display following messages in sequence:

var msg1 = "Welcome to JS Land...";
var msg2 = "Happ Coding!\nPrevent this page from creating aditional dialogs.";

alert(msg1);
alert(msg2);