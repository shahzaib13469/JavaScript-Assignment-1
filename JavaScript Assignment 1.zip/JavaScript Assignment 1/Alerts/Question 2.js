// 2. Write a script to display following message on your web
// page:

var msg = "Error! Enter a Valid Password";

alert(msg)