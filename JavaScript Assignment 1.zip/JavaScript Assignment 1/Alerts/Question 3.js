// 3. Write a script to display following message on your web
// page: (Hint : Use line break)

var msg = "Welcome to JS Land...\nHappy Coding!";
alert(msg);
console.log(msg)